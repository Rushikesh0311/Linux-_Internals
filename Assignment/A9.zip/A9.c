/*
A09 - Implement communication between two related processes using one pipe*/
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
int main(int argc,char* argv[]){

    if(argc == 1)
    {
        printf("./pipe (No arguments)  Error: No arguments passed Usage: ./pipe   <command1 > '|'   <command2>\n");
        _exit(0);
    }
    if(argc < 3)
    {
        printf("Error: Insufficient arguments passed Usage: ./pipe  <command1 > '|'   <command2>\n");
        _exit(0);
    }
                                                
    int pipefd[2];

    if(pipe(pipefd) == -1)
    {
        perror("pipe");
        return -1;
    }

    __pid_t c1 = fork();

    int posi;
    for(int i=0;i<argc;i++)
    {
        if(!strcmp(argv[i],"|"))
        {
            argv[i] = NULL;
            posi = i + 1;
            break;
        }
        
    }

    if(c1 > 0)
    {
        __pid_t child2 = fork();
        if(child2 > 0)
        {
            close(pipefd[0]);
            close(pipefd[1]);

            //wait for child 2
            for(int i=0;i<2;i++)
                wait(NULL);
        }
        else if(child2 == 0)
        {
            close(pipefd[1]);
            dup2(pipefd[0],0);
            execvp(argv[posi],argv + posi);
        }

    }
    else if(c1 == 0)
    {
         //close the unused pipe
        close(pipefd[0]);
        //sleep(5);

        dup2(pipefd[1],1);
        execvp(argv[1],&argv[1]);

    }
}
